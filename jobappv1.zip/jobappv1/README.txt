Sprint #1
Build UI for main page
Build UI for signUp and SignIn
Create Account
Login with an Account
Create Profile functionality

The Job Search application we built allows the user to login with default credentials(username, password) and view their current profile information.
The app also allows the user to create a new user to log in with.