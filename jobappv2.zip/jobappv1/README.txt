Sprint #2
Build UI for posting/editing jobs
Post a job position
Remove a job position
Add functionality for deleting documents
Add functionality for uploading documents

In addition to the previous version of the app which allowed for login with default credentials(username, password), creation of users
and view of the profile data, the current version allows the user to view a splash page with links to all the user can do. The first
option for the user is to view available jobs. The user has the ability to CRUD any job. Next the user can view their profile info.
Lastly, the user can log out of the application.
